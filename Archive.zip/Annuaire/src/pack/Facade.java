package pack;

import java.util.Collection;
import java.util.Date;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Singleton
@Path("/")
public class Facade {

	@PersistenceContext
	EntityManager em;
	
	@POST
	@Path("/adduser")
    @Consumes({ "application/json" })
	public void addUtilisateur(Utilisateur u) {
		String s1 = u.getPseudo();
		String s2 = u.getMail();
		String s3 = u.getPasswordHash();
		Utilisateur ur = new Utilisateur(s1, s2, s3);
		em.persist(ur);
	}
	
	@POST
	@Path("/addpremium")
    @Consumes({ "application/json" })
	public void addPremium(Premium p) {
		em.persist(p);
	}
	
	@POST
	@Path("/adddoc")
    @Consumes({ "application/json" })
	public void addDoc(Documentation d) {
		em.persist(d);
	}
	
	@POST
	@Path("/addresultat")
    @Consumes({ "application/json" })
	public void addResult(Resultat r) {
		em.persist(r);
	}
	
	@POST
	@Path("/addclassement")
    @Consumes({ "application/json" })
	public void addClassement(Classement c) {
		em.persist(c);
	}
	
	@POST
	@Path("/addchallenge")
    @Consumes({ "application/json" })
	public void addChallenge(Challenge c) {
		em.persist(c);
	}
	
	@POST
	@Path("/addmessage")
    @Consumes({ "application/json" })
	public void addMessage(Message m) {
		em.persist(m);
	}
	
	
	// au-dessus sont les fonctions qui permettent d'ajouter un objet à la db
	
	
	
	
	//Page classement.html
	
	@GET
	@Path("/listusers")
    @Produces({ "application/json" })
	public Collection<Utilisateur> listUsers() {
		return em.createQuery("from Utilisateur", Utilisateur.class).getResultList();
	}
	
	@GET
	@Path("/initusers")
    @Produces({ "application/json" })
	public Boolean initUsers() {
		Utilisateur d1 = new Utilisateur("alexandre", "alexandre@mail.com", "mdp1");
		Utilisateur d2 = new Utilisateur("jade", "jade@mail.com", "mdp2");
		Utilisateur d3 = new Utilisateur("thomas", "thomas@mail.com", "mdp3");
		Utilisateur d4 = new Utilisateur("manuel", "manuel@mail.com", "mdp4");
		addUtilisateur(d1);addUtilisateur(d2);addUtilisateur(d3);addUtilisateur(d4);
		return true;
	}
	
	
	
	
	
	@GET
	@Path("/listtop")
    @Produces({ "application/json" })
	public Collection<Utilisateur> classement() {
		return em.createQuery("from Utilisateur", Utilisateur.class).getResultList();
	}
	
	//Fin page classement.html
	
	//Page documentation.html
	
	@GET
	@Path("/listdocs")
    @Produces({ "application/json" })
	public Collection<Documentation> listDocumentations() {
		return em.createQuery("from Documentation", Documentation.class).getResultList();
	}
	
	@GET
	@Path("/initdocs")
    @Produces({ "application/json" })
	public Boolean initDocs() {
		Documentation d1 = new Documentation("Documentation 1 - Les bases de Angular", "Apprenez ici les bases de angular !");
		Documentation d2 = new Documentation("Documentation 2 - Les bases de React", "Apprenez ici les bases de React !");
		Documentation d3 = new Documentation("Documentation 3 - Les bases pour programmer en C", "Apprenez ici à faire un shellcode en C !");
		Documentation d4 = new Documentation("Documentation 4 - Les bases pour construire un hélicoptère", "Apprenez ici à construire un hélicoptère avec du fil et un cure-dent");
		addDoc(d1);addDoc(d2);addDoc(d3);addDoc(d4);  //on initalise pour éviter de le faire à la main
		return true;
	}
	
	//Fin page documentation.html
	
	//Page challenge.html concrètement home.html
	
	@GET
	@Path("/initchallenges")
    @Produces({ "application/json" })
	public Boolean initChallenges() {
		Challenge c1 = new Challenge("Challenge 1", "Ici gît la description du premier challenge - indice : la réponse vaut Reponse 1", 5, "Reponse 1");
		Challenge c2 = new Challenge("Challenge 2", "Ici gît la description du deuxième challenge", 1, "Reponse 2");
		Challenge c3 = new Challenge("Challenge 3", "Ici gît la description du troisième challenge", 9, "Reponse 3");
		Challenge c4 = new Challenge("Challenge 4", "Ici gît la description du quatrième challenge", 2, "Reponse 4");
		addChallenge(c1);addChallenge(c2);addChallenge(c3);addChallenge(c4);  //on initalise pour éviter de le faire à la main
		return true;
	}
	
	@GET
	@Path("/listchallenges")
    @Produces({ "application/json" })
	public Collection<Challenge> listChallenges() {
		return em.createQuery("from Challenge", Challenge.class).getResultList();
	}
	
	@POST
	@Path("/getchallenge")
    @Consumes({ "application/json" })
	public Challenge getChallenge(Challenge c) {
		String titre = c.getTitre();
		Challenge challenge = (Challenge) em.createQuery("SELECT c FROM Challenge c WHERE c.titre = :titre")
                .setParameter("titre", titre)
                .getSingleResult();
		return challenge;
	}
	
	@POST
	@Path("/validerchallenge")
    @Consumes({ "application/json" })
	public Boolean validerChallenge(Challenge c) {
		String rep = c.getReponse();
		String s = c.getTitre();
		String tk = c.getTexte();
		try {
		System.out.println(rep + " rep:titre " + s);
		Challenge challenge = (Challenge) em.createQuery("SELECT c FROM Challenge c WHERE c.titre = :titre AND c.reponse = :reponse")
                .setParameter("titre", s)
                .setParameter("reponse", rep)
                .getSingleResult();
		System.out.println("Challenge bon !");
		
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.token = :token")
                .setParameter("token", tk)
                .getSingleResult();
		System.out.println("USER OK §");
		Resultat r = new Resultat(s, challenge.getPoints());
		if(TestRes(utilisateur, r)) {
			System.out.println("Challenge déjà validé");
			return false;}
		else {
			r.setUtilisateur(utilisateur);
			addResult(r);
			utilisateur.incScore(challenge.getPoints());
			System.out.println("RESULT OK");
			return true;}
		} catch(Exception e) {System.out.println("EXCEPTION VALIDER CHALLENGE !");return false;}
	}
	
	public Boolean TestRes(Utilisateur u, Resultat r) {
		return u.getResults().contains(r);
	}
	
	//Fin page challenge.html
	
	//Page signup.html
	
	//on appelle adduser du top
	
	//Fin page signup.html
	
	//Page signin.html
	
	@POST
	@Path("/login")
    @Consumes({ "application/json" })
	@Produces({ "application/json" })
	public Utilisateur verifLogin(Utilisateur ue) {
		String psd = ue.getPseudo();
		String mdp = ue.getPasswordHash();
		System.out.println("Requête SQL pour les utilisateurs commencée !");
		try {
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.pseudo = :pseudo AND u.passwordHash = :mdp")
                .setParameter("pseudo", psd)
                .setParameter("mdp", mdp)
                .getSingleResult();
		System.out.println("Requête SQL pour les utilisateurs faite !");
		utilisateur.generateToken(); //faut écrire le code de cette fonction
		return utilisateur;} catch(Exception e) {System.out.println("EXCEPTION - lOGIN FAILED !");return null;}
	}
	
	//Fin page signup.html
	
	//Début premium.html
	
	@GET
	@Path("/initpremium")
    @Produces({ "application/json" })
	public Boolean initPremium() {
		Premium c1 = new Premium("code1");
		Premium c2 = new Premium("code2");
		Premium c3 = new Premium("code3");
		addPremium(c1);addPremium(c2);addPremium(c3);  //on initalise pour éviter de le faire à la main
		return true;
	}
	
	@POST
	@Path("/gopremium")
    @Consumes({ "application/json" })
	public Boolean premium(String s) {
		String code = s.split("@")[0];
		String token = s.split("@")[1];
		try {
		Premium p = (Premium) em.createQuery("SELECT p FROM Premium p WHERE p.code = :code")
                .setParameter("code", code)
                .getSingleResult();
		changePremium(token);
		System.out.println("User passé vip");
		return true;} catch(Exception e) {return false;}
	}
	
	public void changePremium(String s) {
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.token = :token")
                .setParameter("token", s)
                .getSingleResult();
		utilisateur.SetPremium("oui");
		System.out.println("On est bien passé premium !");
	}
	
	//Fin premium.html
	
	//Début compte.html
	
	@POST
	@Path("/getuser")
    @Consumes({ "application/json" })
	@Produces({ "application/json" })
	public Utilisateur getUser(String s) {
		System.out.println("On rentre dans getUser avec comme paramètre: "+ s + " !");
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.token = :token")
                .setParameter("token", s)
                .getSingleResult();
		System.out.println("Requête OK: "+ utilisateur.getPremium() + " mail: "+ utilisateur.getMail());
		return utilisateur;
	}
	
	@POST
	@Path("/deluser")
    @Consumes({ "application/json" })
	@Produces({ "application/json" })
	public void delUser(String s) {
		try {
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.token = :token")
                .setParameter("token", s)
                .getSingleResult();
		em.remove(utilisateur);
		System.out.println("Utilisateur supprimé !");}
		catch(Exception e) {System.out.println("Utilisateur non supprimé -> ECHEC !");}
	}
	
	@POST
	@Path("/changemdp")
    @Consumes({ "application/json" })
	public void changeMdpUser(Utilisateur u) {
		String s = u.getToken();
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.token = :token")
                .setParameter("token", s)
                .getSingleResult();
		utilisateur.setPasswordHash(u.getPasswordHash());
		System.out.println("Mot de passe changé !");
	}
	
	
	//début communauté.html
	
	@GET
	@Path("/listmessages")
    @Produces({ "application/json" })
	public Collection<Message> listMessages() {
		return em.createQuery("from Message", Message.class).getResultList();
	}
	
	@POST
	@Path("/sendmessage")
    @Consumes({ "application/json" })
	public Boolean sendMessage(Message m) {
		String pseudo = m.sender.split("_")[1];
		try {
		Message msg = new Message(m.texte, pseudo); //date à gérer
		addMessage(msg);
		System.out.println("Message ok");
		return true;} catch(Exception e) {return false;}
	}
	
	@GET
	@Path("/initmsg")
    @Produces({ "application/json" })
	public Boolean initMessages() {
		Message c1 = new Message("T'as acheté du pain Jade ?", "alexandre");
		Message c2 = new Message("Oui, j'ai pris une baguette.", "jade");
		Message c3 = new Message("J'ai ramené de la mousse de canard perso !", "manuel");
		addMessage(c1);addMessage(c2);addMessage(c3);
		return true;
	}
	
}