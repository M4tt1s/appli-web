package pack;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Resultat {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	
	@JsonIgnore
	@ManyToOne
	private Utilisateur utilisateur;
	
	String titreChallenge;
	
	Integer score;
	
	public Resultat() {}
	
	public Resultat(String s, Integer n) {
		this.titreChallenge = s;
		this.score = n;
	}
	
	
	public void setUtilisateur(Utilisateur u) {
		this.utilisateur = u;
	}
	
	public void setTitreChallenge(String s) {
		this.titreChallenge = s;
	}
	
	public void setScore(Integer n) {
		this.score = n;
	}

	
	public Utilisateur getUtilisateur() {
		return this.utilisateur;
	}
	
	public String getTitreChallenge() {
		return this.titreChallenge;
	}
	
	public Integer getScore() {
		return this.score;
	}
}