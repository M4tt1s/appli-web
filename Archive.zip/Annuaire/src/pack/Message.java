package pack;
import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Message {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	
	String texte;
	Date date;
	String sender;
	
	
	public Message() {}
	
	public Message(Date d, String t) {
		this.date = d;
		this.texte = t;
	}
	
	public Message(String t, String s) {
		Calendar calendar = Calendar.getInstance();
		Date date = calendar.getTime();
		this.texte = t;
		this.sender = s;
		//System.out.println("Current date and time: " + date.toString());
	}
	
	public void setDate(Date d) {
		this.date = d;
	}
	
	public void setTexte(String t) {
		this.texte = t;
	}
	
	public void setSender(String u) {
		this.sender = u;
	}
	
	public Date getDate() {
		return this.date;
	}
	
	public String getTexte() {
		return this.texte;
	}
	
	public String getSender() {
		return this.sender;
	}
}