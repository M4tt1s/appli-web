package pack;
import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Utilisateur {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	
	String pseudo;
	String mail;
	String passwordHash;
	String token;
	Boolean premium;
	
	@JsonIgnore
	@OneToMany(mappedBy="utilisateur", fetch = FetchType.EAGER)
	Collection<Resultat> results;
	
	@JsonIgnore
	@OneToOne
	Classement classement;
	
	public Utilisateur() {}
	
	public Utilisateur(String s1, String s2, String s3) {
		this.pseudo = s1;
		this.mail = s2;
		this.passwordHash = s3;
		this.premium = false;
	}
	
	public Utilisateur(String s1, String s2) {
		this.pseudo = s1;
		this.passwordHash = s2;
		this.premium = false;
	}
	
	public void setPseudo(String s) {
		this.pseudo = s;
	}
	
	public void setMail(String s) {
		this.mail = s;
	}
	
	public void setPasswordHash(String s) {
		this.passwordHash = s;
	}
	
	public void SetPremium(Boolean b) {
		this.premium = b;
	}
	
	public String getPseudo() {
		return this.pseudo;
	}
	
	public String getMail() {
		return this.mail;
	}
	
	public String getPasswordHash() {
		return this.passwordHash;
	}
	
	public Boolean getPremium() {
		return this.premium;
	}
	
	public Classement getClassement() {
		return this.classement;
	}
	
	public void setToken(String s) {
		this.token = s;
	}
	
	public String getToken() {
		return this.token;
	}
	
	public void generateToken() {
		String token = "token_"+this.getPseudo();
		this.setToken(token);
		System.out.println("Génération de token de session !!!"); //qu'en faire après
	}
}