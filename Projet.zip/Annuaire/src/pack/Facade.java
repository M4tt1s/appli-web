package pack;

import java.util.Collection;

import javax.ejb.Singleton;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Singleton
@Path("/")
public class Facade {

	@PersistenceContext
	EntityManager em;
	
	@POST
	@Path("/adduser")
    @Consumes({ "application/json" })
	public void addUtilisateur(Utilisateur u) {
		em.persist(u);
	}
	
	@POST
	@Path("/addpremium")
    @Consumes({ "application/json" })
	public void addPremium(Premium p) {
		em.persist(p);
	}
	
	@POST
	@Path("/adddoc")
    @Consumes({ "application/json" })
	public void addDoc(Documentation d) {
		em.persist(d);
	}
	
	@POST
	@Path("/addresultat")
    @Consumes({ "application/json" })
	public void addResult(Resultat r) {
		em.persist(r);
	}
	
	@POST
	@Path("/addclassement")
    @Consumes({ "application/json" })
	public void addClassement(Classement c) {
		em.persist(c);
	}
	
	@POST
	@Path("/addchallenge")
    @Consumes({ "application/json" })
	public void addChallenge(Challenge c) {
		em.persist(c);
	}
	
	@POST
	@Path("/addmessage")
    @Consumes({ "application/json" })
	public void addMessage(Message m) {
		em.persist(m);
	}
	
	
	// au-dessus sont les fonctions qui permettent d'ajouter un objet à la db
	
	
	
	
	//Page classement.html
	
	@GET
	@Path("/listusers")
    @Produces({ "application/json" })
	public Collection<Utilisateur> listUsers() {
		return em.createQuery("from Utilisateur", Utilisateur.class).getResultList();
	}
	
	@GET
	@Path("/listtop10")
    @Produces({ "application/json" })
	public Collection<Classement> classement() {
		return em.createQuery("from Classement", Classement.class).getResultList();
	}
	
	@GET
	@Path("/listclassementusercourant")
    @Produces({ "application/json" })
	public Classement listUCourantClassement(Utilisateur u) {
		return u.getClassement();
	}
	
	//Fin page classement.html
	
	//Page documentation.html
	
	@GET
	@Path("/listdocu")
    @Produces({ "application/json" })
	public Collection<Documentation> listDocumentations() {
		return em.createQuery("from Documentation", Documentation.class).getResultList();
	}
	
	//Fin page documentation.html
	
	//Page challenge.html concrètement home.html
	
	@GET
	@Path("/initchallenges")
    @Produces({ "application/json" })
	public Boolean initChallenges() {
		Challenge c1 = new Challenge("Challenge 1", "Description 1", 5, "Reponse 1");
		Challenge c2 = new Challenge("Challenge 2", "Description 2", 1, "Reponse 2");
		Challenge c3 = new Challenge("Challenge 3", "Description 3", 9, "Reponse 3");
		Challenge c4 = new Challenge("Challenge 4", "Description 4", 2, "Reponse 4");
		addChallenge(c1);addChallenge(c2);addChallenge(c3);addChallenge(c4);  //on initalise pour éviter de le faire à la main
		return true;
	}
	
	@GET
	@Path("/listchallenges")
    @Produces({ "application/json" })
	public Collection<Challenge> listChallenges() {
		return em.createQuery("from Challenge", Challenge.class).getResultList();
	}
	
	@POST
	@Path("/getchallenge")
    @Consumes({ "application/json" })
	public Challenge getChallenge(Challenge c) {
		String titre = c.getTitre();
		Challenge challenge = (Challenge) em.createQuery("SELECT c FROM Challenge c WHERE c.titre = :titre")
                .setParameter("titre", titre)
                .getSingleResult();
		return challenge;
	}
	
	@POST
	@Path("/validerchallenge")
    @Consumes({ "application/json" })
	public Boolean validerChallenge(Challenge c, Challenge current) {
		String rep = c.getReponse();
		String s = current.getTitre();
		try {
		Challenge challenge = (Challenge) em.createQuery("SELECT c FROM Challenge c WHERE c.titre = :titre AND c.reponse = :reponse")
                .setParameter("titre", s)
                .setParameter("reponse", rep)
                .getSingleResult();
		return true;} catch(Exception e) {return false;}
	}

	@POST
	@Path("/addcompresult")
    @Consumes({ "application/json" })
	public Boolean addMessage(String reponse, String titre) {
		Challenge c = (Challenge) em.createQuery("SELECT FROM Challenge WHERE TITRE =" + titre + "", Challenge.class);
		return reponse.equals(c.getReponse());
	}
	
	//Fin page challenge.html
	
	//Page signup.html
	
	//on appelle adduser du top
	
	//Fin page signup.html
	
	//Page signin.html
	
	@POST
	@Path("/login")
    @Consumes({ "application/json" })
	public Boolean verifLogin(Utilisateur ue) {
		String psd = ue.getPseudo();
		String mdp = ue.getPasswordHash();
		try {
		Utilisateur utilisateur = (Utilisateur) em.createQuery("SELECT u FROM Utilisateur u WHERE u.pseudo = :pseudo AND u.passwordHash = :mdp")
                .setParameter("pseudo", psd)
                .setParameter("mdp", mdp)
                .getSingleResult();
		utilisateur.generateToken(); //faut écrire le code de cette fonction
		return true;} catch(Exception e) {return false;}
	}
	
	//Fin page signup.html
	
	//Début premium.html
	
	@GET
	@Path("/initpremium")
    @Produces({ "application/json" })
	public Boolean initPremium() {
		Premium c1 = new Premium("code1");
		Premium c2 = new Premium("code2");
		Premium c3 = new Premium("code3");
		addPremium(c1);addPremium(c2);addPremium(c3);  //on initalise pour éviter de le faire à la main
		return true;
	}
	
	@POST
	@Path("/gopremium")
    @Consumes({ "application/json" })
	public Boolean premium(Premium pr) {
		String code = pr.getCode();
		try {
		Premium p = (Premium) em.createQuery("SELECT p FROM Premium p WHERE p.code = :code")
                .setParameter("code", code)
                .getSingleResult();
		//U.setPremium(true); -> comment on récupère cet utilisateur ?
		return true;} catch(Exception e) {return false;}
	}
	
	//Fin premium.html
	
}