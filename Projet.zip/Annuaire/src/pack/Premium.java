package pack;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Premium {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	private String code;
	
	public Premium(){}
	
	public Premium(String s) {
		this.code = s;
	}
	
	public void setCode(String s) {
		this.code = s;
	}
	
	public String getCode(){
		return this.code;
	}	
}