package pack;

import java.util.Collection;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Challenge {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	Boolean premium;
	
	@JsonIgnore
	@OneToMany(mappedBy="challenge", fetch = FetchType.EAGER)
	private Collection<Resultat> result; 
	
	String titre;
	String text; // Peut-être les mettre dans un fichier et les récupérer à partir d'un parser pour l'initialisation
	Integer points;
	String reponse;
	
	public Challenge() {
	}
	
	public Challenge(String s1, String ts2, int n, String r) {
		this.titre = s1;
		this.text = ts2;
		this.points = n;
		this.reponse = r;
	}
	
	public void setTexte(String s) {
		this.text = s;
	}
	
	public void setTitre(String s) {
		this.titre = s;
	}
	
	public void setPoints(Integer n) {
		this.points = n;
	}
	
	public void SetPremium(Boolean b) {
		this.premium = b;
	}
	
	public String getTitre() {
		return this.titre;
	}
	
	public String getTexte() {
		return this.text;
	}
	
	public Integer getPoints() {
		return this.points;
	}
	
	public Boolean getPremium() {
		return this.premium;
	}
	
	public String getReponse() {
		return this.reponse;
	}
}